# CRUD Mundo

## Sobre o projeto
Aplicação web para gerenciamento de dados geográficos, com cadastro e consulta de continentes, países, cidades e governantes.

## Funcionalidades
- Gerenciamento de Países, Cidades, Continentes e Governantes
- Busca dinâmica no Front-End
- Validação de exclusão com alertas nativos

## Tecnologias utilizadas
- HTML5 / CSS3 / JavaScript
- PHP (PDO)
- MySQL

## Estrutura do projeto
- `assets/`: Arquivos estáticos (CSS e JS)
- `database/`: Scripts de criação do banco de dados
- `pages/`: Interfaces e tabelas da aplicação
- `src/`: Lógica PHP e conexão com o banco de dados

## Como executar
1. Importe o arquivo `database/database.sql` no seu MySQL.
2. Configure as credenciais em `src/conexao.php`.
3. Inicie um servidor PHP local ou Apache (XAMPP/WAMP) apontado para a raiz do projeto.

## Autor
Seu Nome Aqui

CREATE DATABASE IF NOT EXISTS bd_mundo CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bd_mundo;

CREATE TABLE IF NOT EXISTS continentes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    populacao BIGINT NOT NULL,
    area DECIMAL(12,2) NOT NULL,
    total_paises INT NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS paises (
    id INT AUTO_INCREMENT PRIMARY KEY,
    continente_id INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    populacao BIGINT NOT NULL,
    area DECIMAL(12,2) NOT NULL,
    idioma VARCHAR(50) NOT NULL,
    clima VARCHAR(50) NOT NULL,
    regime_politico VARCHAR(50) NOT NULL,
    moeda VARCHAR(50) NOT NULL,
    FOREIGN KEY (continente_id) REFERENCES continentes(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS cidades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pais_id INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    populacao BIGINT NOT NULL,
    area DECIMAL(12,2) NOT NULL,
    clima VARCHAR(50) NOT NULL,
    data_fundacao DATE NOT NULL,
    FOREIGN KEY (pais_id) REFERENCES paises(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS governantes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pais_id INT NULL,
    cidade_id INT NULL,
    nome VARCHAR(100) NOT NULL,
    partido_politico VARCHAR(100) NOT NULL,
    data_nascimento DATE NOT NULL,
    idade INT NOT NULL,
    data_inicio_mandato DATE NOT NULL,
    data_fim_mandato DATE NOT NULL,
    FOREIGN KEY (pais_id) REFERENCES paises(id) ON DELETE SET NULL,
    FOREIGN KEY (cidade_id) REFERENCES cidades(id) ON DELETE SET NULL
);

<?php
require_once "conexao.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $continente_id = $_POST['continente_id'] ?? null;
    $nome = $_POST['nome'] ?? '';
    $populacao = $_POST['populacao'] ?? 0;
    $area = $_POST['area'] ?? 0;
    $idioma = $_POST['idioma'] ?? '';
    $clima = $_POST['clima'] ?? '';
    $regime_politico = $_POST['regime_politico'] ?? '';
    $moeda = $_POST['moeda'] ?? '';

    if (!empty($nome) && !empty($continente_id)) {
        $sql = "INSERT INTO paises (continente_id, nome, populacao, area, idioma, clima, regime_politico, moeda) 
                VALUES (:continente_id, :nome, :populacao, :area, :idioma, :clima, :regime_politico, :moeda)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':continente_id', $continente_id, PDO::PARAM_INT);
        $stmt->bindValue(':nome', $nome);
        $stmt->bindValue(':populacao', $populacao, PDO::PARAM_INT);
        $stmt->bindValue(':area', $area);
        $stmt->bindValue(':idioma', $idioma);
        $stmt->bindValue(':clima', $clima);
        $stmt->bindValue(':regime_politico', $regime_politico);
        $stmt->bindValue(':moeda', $moeda);
        
        $stmt->execute();
        header("Location: ../pages/paises.php");
        exit();
    }
}
?>

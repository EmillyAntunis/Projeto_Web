document.addEventListener("DOMContentLoaded", () => {
    const searchInput = document.getElementById("search");
    if (searchInput) {
        searchInput.addEventListener("keyup", () => {
            const filter = searchInput.value.toLowerCase();
            const rows = document.querySelectorAll("table tbody tr");
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? "" : "none";
            });
        });
    }

    const deleteForms = document.querySelectorAll(".form-delete");
    deleteForms.forEach(form => {
        form.addEventListener("submit", (e) => {
            if (!confirm("Tem certeza que deseja excluir este registro?")) {
                e.preventDefault();
            }
        });
    });
});

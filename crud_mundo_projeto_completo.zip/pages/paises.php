<?php
require_once "../src/conexao.php";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Gerenciamento de Países</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Gerenciamento de Países</h1>
    <input type="text" id="search" placeholder="Buscar país...">
    <script src="../assets/js/main.js"></script>
</body>
</html>
